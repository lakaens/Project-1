#include <iostream>
#include "include/SDL.h"
#pragma comment( lib, "SDL/lib/x86/SDL2.lib")
#pragma comment( lib, "SDL/lib/x86/SDL2main.lib")


int main(int argc, char* args[]){

	SDL_Init(SDL_INIT_EVERYTHING);

	


SDL_Quit();




return 0;
}