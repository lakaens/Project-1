#include "Globals.h"
#include "Application.h"
#include "ModuleTextures.h"
#include "ModuleRender.h"
#include "ModulePlayer.h"
#include "ModuleIntro.h"
#include "ModuleFadeToBlack.h"
#include "ModuleInput.h"
#include "ModuleSceneSpace.h"


ModuleIntro::ModuleIntro()
{
	background.x = 0;
	background.y = 0;
	background.w = 384;
	background.h = 256;
}

ModuleIntro::~ModuleIntro()
{}

// Load assets
bool ModuleIntro::Start()
{
	LOG("Loading space scene");

	intro = App->textures->Load("rtype/intro.png");

	return true;
}

// UnLoad assets
bool ModuleIntro::CleanUp()
{
	LOG("Unloading space scene");

	App->textures->Unload(intro);

	return true;
}

// Update: draw background
update_status ModuleIntro::Update()
{
	// Draw everything --------------------------------------
	App->render->Blit(intro, 0, 0, &background, NULL);

	if (App->input->keyboard[SDL_SCANCODE_SPACE] == 1 && state) {
		state = false;
		App->fade->FadeToBlack(this, App->scene_space, 1);
		state = true;
	}

	return UPDATE_CONTINUE;
}