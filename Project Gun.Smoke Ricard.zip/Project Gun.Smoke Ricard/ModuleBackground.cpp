#include "Globals.h"
#include "Application.h"
#include "ModuleTextures.h"
#include "ModuleRender.h"
#include "ModuleAudio.h"
#include "ModuleBackground.h"
#include "ModuleStage2.h"
#include "ModuleFadeToBlack.h"
#include "ModuleInput.h"

ModuleBackground::ModuleBackground() {
	background.x = 0;
	background.y = 0;
	background.w = 224;
	background.h = 3200;
}

ModuleBackground::~ModuleBackground() {

}

bool ModuleBackground::Start() {

	bool ret = true;
	texture = App->textures->Load("mapa1.png"); //Asignem a la variable puntero de textura del modul background, la carrega de la textura a partir del punter extern a la clase application, i d'aqui al modul "textures". Carreguem el mapa.
	if (texture == nullptr) {
		LOG("Texture error: %s", SDL_GetError());
		ret = false;
	}

	return ret;
}

bool ModuleBackground::CleanUp()
{

	LOG("Unloading First Map");

	return true;
}


update_status ModuleBackground::Update() {
	update_status ret = UPDATE_CONTINUE;
	
	if (!App->render->Blit(texture, 0, -3000 + SCREEN_HEIGHT, &background, 0.75f)) {
		ret = UPDATE_ERROR;
		LOG("Blit error: %s", SDL_GetError());

	}

	if (App->input->keyboard[SDL_SCANCODE_SPACE] == 1) 
	{

		App->fade->FadeToBlack(App->background, App->Stage2, 0.7f);

	}

	return ret;
	
}
