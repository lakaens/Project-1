#ifndef MODULEPLAYER_H
#define MODULEPLAYER_H

#include "Module.h"
#include "Animation.h"
#include "Globals.h"
//#include "p2Point.h"

struct SDL_Texture;

class ModulePlayer : public Module
{
public:
	ModulePlayer();
	~ModulePlayer();

	bool Start();
	update_status Update();

public:

	SDL_Texture* graphics = nullptr;
	Animation player;
	Animation forward;
	Animation backward;
	//iPoint position;

};

#endif
