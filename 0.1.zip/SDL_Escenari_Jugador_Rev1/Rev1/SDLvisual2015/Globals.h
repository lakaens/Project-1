#include "include/SDL.h"
#include "include/SDL_image.h"
#include "include/SDL_mixer.h"
#pragma comment( lib, "SDL/lib/x86/SDL2.lib")
#pragma comment( lib, "SDL/lib/x86/SDL2_image.lib")
#pragma comment( lib, "SDL/lib/x86/SDL2main.lib")
#pragma comment( lib, "SDL/lib/x86/SDL2_mixer.lib")

#ifndef GLOBALS_H
#define GLOBALS_H
struct variables {

	SDL_Surface* screen = NULL;

	SDL_Texture* screen2 = NULL;

	SDL_Surface* jugador = NULL;

	int screenwidth, screenheight; // amplada i alcada de la pantalla.

	SDL_Rect displayrect;

	Mix_Chunk* fire = NULL;

	Mix_Music* soundtrack = NULL;
} v;


SDL_Event event;
		bool running = true;
		bool up = false;
		bool right = false;
		bool left = false;
		bool down = false;
		bool bullet = false;
		bool bullet2 = false;
		bool bullet3 = false;

#endif
