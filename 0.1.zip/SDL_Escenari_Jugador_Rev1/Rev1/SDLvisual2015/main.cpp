#include <iostream>
#include "Globals.h"
#include "Draw.h"
#include"Window.h"
#include"renderer.h"
#include "include/SDL.h"
#include "include/SDL_image.h"
#include "include/SDL_mixer.h"
#pragma comment( lib, "SDL/lib/x86/SDL2.lib")
#pragma comment( lib, "SDL/lib/x86/SDL2_image.lib")
#pragma comment( lib, "SDL/lib/x86/SDL2main.lib")
#pragma comment( lib, "SDL/lib/x86/SDL2_mixer.lib")


int main(int argc, char* args[]) {
//-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
	SDL_Init(SDL_INIT_EVERYTHING|SDL_INIT_AUDIO);

	Window = SDL_CreateWindow("GUN.SMOKE", POSITIONX, POSITIONY, WIDTH, HEIGHT, SDL_WINDOW_SHOWN);  // crea una finestra amb un nom, posicio x, y, tamany i flags.

	renderer = SDL_CreateRenderer(Window, -1, SDL_RENDERER_PRESENTVSYNC | SDL_RENDERER_ACCELERATED);  //Genera la finestra i sincronitza les imatges dins del Window.

//-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

	Mix_Init(MIX_INIT_OGG);
	Mix_OpenAudio(44100, MIX_DEFAULT_FORMAT, 2, 2048);
	v.soundtrack = Mix_LoadMUS("arcadefunk.ogg");
	Mix_PlayMusic(v.soundtrack, -1);
	IMG_INIT_PNG;
//-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
	
	/*CREACIO DE ESCENARI*/

	//Asignem el tamany del rectangle que emmagatzemara la imatge de fondo.

	fondo.x = 0;
	fondo.y = 0;
	fondo.w = 576;
	fondo.h = 3200;


	//background = SDL_CreateTextureFromSurface(renderer, IMG_Load("background.png"));
	background = IMG_LoadTexture(renderer, "stage1r.png");
	
//-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

	/*CREACI� DE PERSONATGE:*/

	//Dimensions recuadre personatge controlable.
	rect.x = WIDTH/2;
	rect.y = 925;
	rect.w = 50;
	rect.h = 50;

	
	billy2 = SDL_CreateTextureFromSurface(renderer, IMG_Load("billy.png")); //el PNG se ha almacenado en la textura.

	SDL_RenderCopy(renderer, billy2, NULL, &rect);    //se copia la textura al rectangulo player.

//-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

		//Balas/Laser.
		rect2.x == (rect.x); //El simbol = asigna la posicio de rect.x , pero no es exacte, el cuadradet no seguia el jugador.
		rect2.y == (rect.y); //El simbol = asigna la posicio de rect.y , pero no es exacte, el cuadradet no seguia el jugador. //-V607
		rect2.w = 3;
		rect2.h = 10;

		
		shot = SDL_CreateTextureFromSurface(renderer, IMG_Load("shot.png"));
		SDL_RenderCopy(renderer, shot, NULL, &rect2);
		v.fire = Mix_LoadWAV("fire.wav");
		
//-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

		while (running) {
			
			if (SDL_PollEvent(&event)) {

				if(event.type == SDL_KEYDOWN){  
				
						switch (event.key.keysym.sym) {
							
						case SDLK_ESCAPE:
							running = false;
							break;

						case SDLK_UP:
							
							up = true;
							break;

						case SDLK_DOWN:
							
							down = true;
							break;

						case SDLK_LEFT:
							
							left = true;
							
							break;

						case SDLK_SPACE: //tir dret.                        //Detecta la tecla space.
							bullet3 = true; //detecta que activa el bolea.
							rect2.x = rect.x + 25;	//es situa a la mateixa posicio X que el rectangle movil.
							rect2.y = rect.y + 45; 
							Mix_PlayChannel(-1, v.fire, 0);
							//es situa a la mateixa posicio Y que el rectangle movil.
							break;

						case SDLK_LCTRL: //tir esquerra
							bullet2 = true;
							rect2.x = rect.x + 25;
							rect2.y = rect.y; 
							Mix_PlayChannel(-1, v.fire, 0);
							break; 

						case SDLK_LALT: //Tir central
							bullet = true;
							rect2.x = rect.x + 25;
							rect2.y = rect.y - 25;
							Mix_PlayChannel(-1, v.fire, 0);
							break;

						case SDLK_RIGHT:
							
							right = true;
							break;

						default:
							break;
						}
					}
				if (event.type == SDL_KEYUP) {

					switch (event.key.keysym.sym) {
	
					case SDLK_UP:
						up = false;
						break;

					case SDLK_DOWN:
						down = false;
						break;

					case SDLK_LEFT:
						left = false;
						break;

					case SDLK_RIGHT:
						right = false;
						break;
					default:
						break;
					}
				}

			}	

			//Limits de la finestra.
			if (rect.y != 0 && up) rect.y -= 5;
			if (rect.y != 526 && down) rect.y += 5;
			if (rect.x != 0 && left) rect.x -= 5;
			if (rect.x != 975 && right) rect.x += 5;
			


			/*moviment d'escenari segons moviment*/
		

			if (down) {
				fondo.y -= 5;
			}
			if (up) {
				fondo.y += 5;
			}


				//Tir recte.    Left ALT
				if (bullet) {
					rect2.y -= 10;
					bullet == bullet;
					
				}

				//Tir diagonal ascendent esquerra   Left control.
				if (bullet2) {
					rect2.x -= 10;
					rect2.y -= 10;
					bullet2 == bullet2;
					
				}

				//Tir diagonal ascendent dret     SPACE 
				if (bullet3) {
					rect2.x += 10;
					rect2.y -= 10;
					bullet3 == bullet3;
					
				}


				//Imprimim escenari.
				
				SDL_SetRenderDrawColor(renderer, 0, 0, 255, 255);

				SDL_RenderCopy(renderer, background, NULL, &fondo);

				
				
				//imprimim personatge.
				
				SDL_RenderCopy(renderer, billy2, NULL, &rect);
				
				
				//Imprimeix les balas.
				SDL_SetRenderDrawColor(renderer, 255, 255, 255, 255);
				SDL_RenderFillRect(renderer, &rect2);
				SDL_RenderCopy(renderer, shot, NULL, &rect2);
				
				//Mostra el rectangle amb la imatge.
				SDL_RenderPresent(renderer); 
			
		}

	SDL_Quit();
	return EXIT_SUCCESS;
}



//cada SDL fillrect rquereix un SDL_RenderCopy 


