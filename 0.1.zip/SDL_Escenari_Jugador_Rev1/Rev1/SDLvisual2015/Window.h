#include "include/SDL.h"
#include "include/SDL_image.h"
#include "include/SDL_mixer.h"
#pragma comment( lib, "SDL/lib/x86/SDL2.lib")
#pragma comment( lib, "SDL/lib/x86/SDL2_image.lib")
#pragma comment( lib, "SDL/lib/x86/SDL2main.lib")
#pragma comment( lib, "SDL/lib/x86/SDL2_mixer.lib")



#ifndef WINDOW_H
#define WINDOW_H

#define SCROLL_SPEED 8
#define POSITIONX 100
#define POSITIONY 100
#define WIDTH 576
#define HEIGHT 1024


SDL_Window* Window = 0;

#endif
