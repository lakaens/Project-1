#include "include/SDL.h"
#include "include/SDL_image.h"
#include "include/SDL_mixer.h"
#pragma comment( lib, "SDL/lib/x86/SDL2.lib")
#pragma comment( lib, "SDL/lib/x86/SDL2_image.lib")
#pragma comment( lib, "SDL/lib/x86/SDL2main.lib")
#pragma comment( lib, "SDL/lib/x86/SDL2_mixer.lib")


#ifndef DRAW_H
#define DRAW_H

SDL_Texture* background = NULL;

SDL_Rect background2;

SDL_Texture* billy2 = NULL;

SDL_Texture* shot = NULL;

SDL_Rect rect, rect2, fondo, fondo2;




#endif
