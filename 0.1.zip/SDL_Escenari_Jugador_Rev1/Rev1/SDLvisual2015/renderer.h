#include "include/SDL.h"
#include "include/SDL_image.h"
#include "include/SDL_mixer.h"
#pragma comment( lib, "SDL/lib/x86/SDL2.lib")
#pragma comment( lib, "SDL/lib/x86/SDL2_image.lib")
#pragma comment( lib, "SDL/lib/x86/SDL2main.lib")
#pragma comment( lib, "SDL/lib/x86/SDL2_mixer.lib")

#ifndef RENDERER_H
#define RENDERER_H

SDL_Renderer* renderer = 0;

#endif
