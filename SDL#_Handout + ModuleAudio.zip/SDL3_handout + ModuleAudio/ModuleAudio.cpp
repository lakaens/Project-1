#include "SDL/include/SDL.h"
#include "ModuleAudio.h"
#include "SDL_mixer\include\SDL_mixer.h"
//
//
//ModuleAudio::ModuleAudio() 
//{
//
//}
//
//
//
//ModuleAudio::~ModuleAudio() 
//{
//
//}
//
//
//
//bool ModuleAudio::Init() 
//{
//	bool ret = true;
//
//	if (SDL_Init(SDL_INIT_AUDIO) < 0)
//	{
//		LOG("SDL_AUDIO could not initialize! SDL_Error:\n");
//		LOG(SDL_GetError());
//		ret = false;
//	}
//	else
//
//	Mix_Init(MIX_INIT_OGG);
//	Mix_OpenAudio(44100, MIX_DEFAULT_FORMAT, 2, 2048);
//	music = Mix_LoadMUS("arcadefunk.ogg");
//	Mix_PlayMusic(music, -1);
//
//
//	return ret;
//}
//
//
//bool ModuleAudio::CleanUp()
//{
//	LOG("Stopping Audio");
//
//	//Destroy window
//	if (music != nullptr)
//		Mix_ChannelFinished(NULL);
//	return true;
//
//}