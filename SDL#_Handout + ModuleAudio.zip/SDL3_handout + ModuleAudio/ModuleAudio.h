#include "SDL_mixer\include\SDL_mixer.h"
#include "Module.h"
#include "Globals.h"

//#ifndef MODULEAUDIO_H
//#define MODULEAUDIO_H
//
//
//class ModuleAudio : public Module {
//
//public:
//	ModuleAudio();
//	~ModuleAudio();
//
//
//	bool Init();
//	
//	bool CleanUp();
//
//
//
//	public:
//	Mix_Music* music = nullptr;
//};
//#endif
